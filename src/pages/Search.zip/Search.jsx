import React, { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useProductStore } from "../store/useProductStore";
import ProductCard from "../components/ProductCard";
// ######################
import { SEARCH_KEYWORD_MAP } from "../utils/searchKeyword";

import "./scss/productList.scss";
import "./scss/Search.scss";

const ITEMS_PER_PAGE = 20;

const normalizeText = (value) => String(value || "").toLowerCase();

// #################################
const expandSearchWords = (query) => {
  const words = normalizeText(query)
    .split(/\s+/)
    .filter(Boolean);


  const expandedWords = [];

  words.forEach((word) => {
    // 원래 검색어 추가
    expandedWords.push(word);

    // SEARCH_KEYWORD_MAP 안의 키워드 가져오기
    const mappedKeywords = SEARCH_KEYWORD_MAP[word];

    // 있으면 추가
    if (mappedKeywords) {
      expandedWords.push(
        ...mappedKeywords.map((keyword) => normalizeText(keyword))
      );
    }
  });

  // 중복 제거
  return [...new Set(expandedWords)];
};


const getSearchText = (item) => {
  const chunks = [
    item.name,
    item.productCode,
    item.category1,
    item.category2,
    ...(item.bullet_points || []),
    ...(item.colors || []),
    ...(item.tag || []),
  ];

  console.log("검색", chunks)
  return normalizeText(chunks.join(" "));

};

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const trimmedQuery = query.trim();
  const { items, onFetchItem } = useProductStore();
  const [inputValue, setInputValue] = useState(query);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    if (items.length === 0) onFetchItem();
  }, [items.length, onFetchItem]);

  useEffect(() => {
    setInputValue(query);
    setCurrentPage(1);
  }, [query]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  // const searchResults = useMemo(() => {
  //   if (!trimmedQuery) return [];

  //   const words = normalizeText(trimmedQuery)
  //     .split(/\s+/)
  //     .filter(Boolean);

  //   return items.filter((item) => {
  //     const searchText = getSearchText(item);
  //     // return words.every((word) => searchText.includes(word));
  //     return words.some((word) => searchText.includes(word));
  //   });
  // }, [items, trimmedQuery]);
  // ################################################
  const searchResults = useMemo(() => {
  if (!trimmedQuery) return [];

  const words = expandSearchWords(trimmedQuery);

  return items.filter((item) => {
    const searchText = getSearchText(item);

    return words.some((word) => searchText.includes(word));
  });
}, [items, trimmedQuery]);

  const totalPages = Math.ceil(searchResults.length / ITEMS_PER_PAGE);
  const pagedItems = searchResults.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );

  const handleSubmit = (event) => {
    event.preventDefault();

    const nextQuery = inputValue.trim();
    if (!nextQuery) return;

    setSearchParams({ q: nextQuery });
  };

  return (
    <main className="product-list-wrap search-page">
      <div className="inner filter-hidden">
        <div className="product-list-wrap filter-hidden is-visible">
          <section className="search-head">
            <p className="search-eyebrow">SEARCH</p>
            <h2>상품 검색</h2>
            <form className="search-form" onSubmit={handleSubmit}>
              <input
                type="search"
                value={inputValue}
                onChange={(event) => setInputValue(event.target.value)}
                placeholder="검색어를 입력하세요"
                aria-label="상품 검색어"
              />
              <button type="submit">검색</button>
            </form>
            {trimmedQuery && (
              <p className="search-summary">
                <strong>{trimmedQuery}</strong> 검색 결과 {searchResults.length}개
              </p>
            )}
          </section>

          {trimmedQuery && searchResults.length > 0 && (
            <div className="product-list">
              <ul>
                {pagedItems.map((item) => (
                  <ProductCard cate={item} key={item.id} />
                ))}
              </ul>
            </div>
          )}

          {trimmedQuery && searchResults.length === 0 && (
            <div className="search-empty">
              <h3>검색 결과가 없습니다.</h3>
              <p>상품명, 컬러, 카테고리명으로 다시 검색해보세요.</p>
              <Link to="/all">전체 상품 보기</Link>
            </div>
          )}

          {!trimmedQuery && (
            <div className="search-empty">
              <h3>찾고 싶은 상품을 검색해주세요.</h3>
              <p>예: bag, denim, black, outerwears</p>
            </div>
          )}

          {totalPages > 1 && (
            <div className="pagination">
              <button
                type="button"
                className="page-btn page-arrow"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                aria-label="Previous page"
              >
                <img src="/images/pages-icon/prev-icon.svg" alt="" />
              </button>
              {Array.from({ length: totalPages }, (_, index) => index + 1).map(
                (pageNumber) => (
                  <button
                    type="button"
                    key={pageNumber}
                    className={`page-btn ${currentPage === pageNumber ? "is-active" : ""}`}
                    onClick={() => setCurrentPage(pageNumber)}
                  >
                    {pageNumber}
                  </button>
                ),
              )}
              <button
                type="button"
                className="page-btn page-arrow"
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
                aria-label="Next page"
              >
                <img src="/images/pages-icon/next-icon.svg" alt="" />
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
